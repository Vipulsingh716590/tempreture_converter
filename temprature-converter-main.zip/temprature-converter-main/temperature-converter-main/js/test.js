document.querySelectorAll('a[href="'+document.URL+'index"]').forEach(function(elem){elem.className += ' current-link'});
