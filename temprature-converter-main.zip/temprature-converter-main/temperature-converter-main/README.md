# Temperature Converter 

Pretty pink temperature converter that allows the user to convert °C to °F and vice versa.

<p>
  <img src="s1.png" alt="Home Page" width="770">
  <img src="s2.png" alt="Fahrenheit to Celcius Page" width="770">
</p>
